<?php
require_once '../init.php';
use core\App;
include App::getConf()->root_path.App::getConf()->action_script;
